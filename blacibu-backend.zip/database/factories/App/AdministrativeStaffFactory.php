<?php

namespace Database\Factories\App;

use App\Models\App\AdministrativeStaff;
use Illuminate\Database\Eloquent\Factories\Factory;

class AdministrativeStaffFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = AdministrativeStaff::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
