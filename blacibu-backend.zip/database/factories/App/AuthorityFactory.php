<?php

namespace Database\Factories\App;

use App\Models\App\Authority;
use Illuminate\Database\Eloquent\Factories\Factory;

class AuthorityFactory extends Factory
{

    protected $model = Authority::class;


    public function definition()
    {
        return [

        ];
    }
}
