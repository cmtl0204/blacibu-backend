<?php

namespace Database\Factories\App;

use App\Models\App\Professional;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProfessionalFactory extends Factory
{
    protected $model = Professional::class;

    public function definition()
    {
        return [

        ];
    }
}
