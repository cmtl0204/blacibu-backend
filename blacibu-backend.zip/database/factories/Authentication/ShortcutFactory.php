<?php

namespace Database\Factories\Authentication;

use App\Models\Authentication\Shortcut;
use Illuminate\Database\Eloquent\Factories\Factory;

class ShortcutFactory extends Factory
{
    protected $model = Shortcut::class;

    public function definition()
    {
        return [

        ];
    }
}
