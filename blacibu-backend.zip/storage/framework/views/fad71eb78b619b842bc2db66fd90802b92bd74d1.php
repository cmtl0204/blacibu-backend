header("Status: 301 Moved Permanently");
header("Location: http://siga.test:4200/#/auht/login?token={$token}");
<?php /**PATH C:\laragon\www\ignug\siga_backend\resources\views/pages/authentication/redirect-login.blade.php ENDPATH**/ ?>